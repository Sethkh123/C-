using System;
using System.Collections.Generic;

public class Program
{
    static List<User> users = new List<User>();
    static List<Quiz> quizzes = new List<Quiz>();

    public static void Main()
    {
        InitializeSampleData(); // Initialize sample data (quizzes)

        while (true)
        {
            Console.WriteLine("Welcome to the Quiz App!");

            User currentUser = LoginOrRegister(); // Login or Register

            if (currentUser == null)
                continue; // Retry login or registration

            // User menu after successful login
            while (true)
            {
                Console.WriteLine($"Logged in as {currentUser.Username}");
                Console.WriteLine("1. Start a new quiz");
                Console.WriteLine("2. View previous quiz results");
                Console.WriteLine("3. View top scores for a quiz");
                Console.WriteLine("4. Change settings (password and date of birth)");
                Console.WriteLine("5. Log out");

                Console.Write("Choose an option: ");
                string option = Console.ReadLine().Trim();

                switch (option)
                {
                    case "1":
                        StartNewQuiz(currentUser);
                        break;
                    case "2":
                        ViewPreviousResults(currentUser);
                        break;
                    case "3":
                        ViewTopScores();
                        break;
                    case "4":
                        ChangeSettings(currentUser);
                        break;
                    case "5":
                        Console.WriteLine("Logging out...");
                        currentUser = null;
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please choose again.");
                        break;
                }

                if (currentUser == null)
                    break; // Break inner loop to go back to login/register
            }
        }
    }

    // Function to handle user login or registration
    static User LoginOrRegister()
    {
        while (true)
        {
            Console.Write("Enter your username: ");
            string username = Console.ReadLine().Trim();

            Console.Write("Enter your password: ");
            string password = Console.ReadLine();

            Console.Write("Enter your date of birth (YYYY-MM-DD): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime dateOfBirth))
            {
                Console.WriteLine("Invalid date format. Please use YYYY-MM-DD.");
                continue;
            }

            // Check if the user exists
            User existingUser = users.Find(u => u.Username == username);
            if (existingUser != null)
            {
                if (existingUser.Password == password)
                {
                    Console.WriteLine("Login successful!");
                    return existingUser;
                }
                else
                {
                    Console.WriteLine("Incorrect password. Please try again.");
                    continue;
                }
            }
            else
            {
                // Register new user
                User newUser = new User(username, password, dateOfBirth);
                users.Add(newUser);
                Console.WriteLine("Registration successful!");
                return newUser;
            }
        }
    }

    // Function to start a new quiz
    static void StartNewQuiz(User user)
    {
        Console.WriteLine("Available Quizzes:");
        for (int i = 0; i < quizzes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {quizzes[i].Title}");
        }

        Console.Write("Choose a quiz to start (1 - {0}): ", quizzes.Count);
        if (!int.TryParse(Console.ReadLine(), out int quizIndex) || quizIndex < 1 || quizIndex > quizzes.Count)
        {
            Console.WriteLine("Invalid input. Please enter a valid quiz number.");
            return;
        }

        Quiz selectedQuiz = quizzes[quizIndex - 1];

        // Simulate quiz taking (display questions and get answers)
        int correctAnswers = 0;
        foreach (Question question in selectedQuiz.Questions)
        {
            Console.WriteLine(question.Text);

            Console.WriteLine("Enter your answer(s), separated by commas:");
            string userAnswer = Console.ReadLine().Trim();

            List<string> userAnswers = new List<string>(userAnswer.Split(','));

            bool allCorrect = true;
            foreach (string answer in question.CorrectAnswers)
            {
                if (!userAnswers.Contains(answer))
                {
                    allCorrect = false;
                    break;
                }
            }

            if (allCorrect && userAnswers.Count == question.CorrectAnswers.Count)
            {
                correctAnswers++;
            }
        }

        // Record quiz result
        QuizResult quizResult = new QuizResult(selectedQuiz.Title, correctAnswers, DateTime.Now);
        user.QuizResults.Add(quizResult);

        Console.WriteLine($"Quiz completed! You got {correctAnswers} out of {selectedQuiz.Questions.Count} questions correct.");
    }

    // Function to view previous quiz results
    static void ViewPreviousResults(User user)
    {
        Console.WriteLine("Previous Quiz Results:");
        foreach (QuizResult result in user.QuizResults)
        {
            Console.WriteLine($"Quiz: {result.QuizTitle}, Date: {result.DateTaken}, Correct Answers: {result.CorrectAnswers}");
        }
    }

    // Function to view top scores for a quiz
    static void ViewTopScores()
    {
        // Implement logic to retrieve and display top scores
        Console.WriteLine("Feature not implemented yet.");
    }

    // Function to change user settings
    static void ChangeSettings(User user)
    {
        Console.Write("Enter new password: ");
        string newPassword = Console.ReadLine();

        Console.Write("Enter new date of birth (YYYY-MM-DD): ");
        if (!DateTime.TryParse(Console.ReadLine(), out DateTime newDateOfBirth))
        {
            Console.WriteLine("Invalid date format. Settings not changed.");
            return;
        }

        user.Password = newPassword;
        user.DateOfBirth = newDateOfBirth;

        Console.WriteLine("Settings changed successfully!");
    }

    // Function to initialize sample data (quizzes)
    static void InitializeSampleData()
    {
        Quiz historyQuiz = new Quiz("History");
        historyQuiz.Questions.Add(new Question("What year did World War II end?", new List<string> { "1945" }));
        historyQuiz.Questions.Add(new Question("Who was the first President of the United States?", new List<string> { "George Washington" }));

        Quiz geographyQuiz = new Quiz("Geography");
        geographyQuiz.Questions.Add(new Question("What is the capital of France?", new List<string> { "Paris" }));
        geographyQuiz.Questions.Add(new Question("Which continent is the Sahara Desert located in?", new List<string> { "Africa" }));

        quizzes.Add(historyQuiz);
        quizzes.Add(geographyQuiz);
    }
}
