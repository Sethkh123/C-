using System;
using System.Collections.Generic;

public class User
{
    public string Username { get; set; }
    public string Password { get; set; }
    public DateTime DateOfBirth { get; set; }
    public List<QuizResult> QuizResults { get; set; }

    public User(string username, string password, DateTime dateOfBirth)
    {
        Username = username;
        Password = password;
        DateOfBirth = dateOfBirth;
        QuizResults = new List<QuizResult>();
    }
}

public class Quiz
{
    public string Title { get; set; }
    public List<Question> Questions { get; set; }

    public Quiz(string title)
    {
        Title = title;
        Questions = new List<Question>();
    }
}

public class Question
{
    public string Text { get; set; }
    public List<string> CorrectAnswers { get; set; }

    public Question(string text, List<string> correctAnswers)
    {
        Text = text;
        CorrectAnswers = correctAnswers;
    }
}

public class QuizResult
{
    public string QuizTitle { get; set; }
    public int CorrectAnswers { get; set; }
    public DateTime DateTaken { get; set; }

    public QuizResult(string quizTitle, int correctAnswers, DateTime dateTaken)
    {
        QuizTitle = quizTitle;
        CorrectAnswers = correctAnswers;
        DateTaken = dateTaken;
    }
}
