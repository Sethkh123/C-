using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class Dictionary
{
    public string Language { get; private set; }
    private List<DictionaryEntry> Entries { get; set; }

    public Dictionary(string language)
    {
        Language = language;
        Entries = new List<DictionaryEntry>();
    }

    public void AddWord(string word, string translation)
    {
        var entry = Entries.FirstOrDefault(e => e.Word == word);
        if (entry == null)
        {
            entry = new DictionaryEntry(word);
            Entries.Add(entry);
        }
        entry.Translations.Add(translation);
    }

    public void ReplaceWord(string oldWord, string newWord)
    {
        var entry = Entries.FirstOrDefault(e => e.Word == oldWord);
        if (entry != null)
        {
            entry.Word = newWord;
        }
    }

    public void ReplaceTranslation(string word, string oldTranslation, string newTranslation)
    {
        var entry = Entries.FirstOrDefault(e => e.Word == word);
        if (entry != null)
        {
            int index = entry.Translations.IndexOf(oldTranslation);
            if (index != -1)
            {
                entry.Translations[index] = newTranslation;
            }
        }
    }

    public void DeleteWord(string word)
    {
        Entries.RemoveAll(e => e.Word == word);
    }

    public void DeleteTranslation(string word, string translation)
    {
        var entry = Entries.FirstOrDefault(e => e.Word == word);
        if (entry != null)
        {
            entry.Translations.Remove(translation);
            if (entry.Translations.Count == 0)
            {
                Entries.Remove(entry);
            }
        }
    }

    public List<string> SearchTranslation(string word)
    {
        var entry = Entries.FirstOrDefault(e => e.Word == word);
        return entry?.Translations;
    }

    public void SaveToFile(string filePath)
    {
        using (var writer = new StreamWriter(filePath))
        {
            writer.WriteLine(Language);
            foreach (var entry in Entries)
            {
                writer.WriteLine(entry.Word + ":" + string.Join(",", entry.Translations));
            }
        }
    }

    public static Dictionary LoadFromFile(string filePath)
    {
        using (var reader = new StreamReader(filePath))
        {
            string language = reader.ReadLine();
            var dictionary = new Dictionary(language);
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                var parts = line.Split(':');
                var word = parts[0];
                var translations = parts[1].Split(',').ToList();
                var entry = new DictionaryEntry(word) { Translations = translations };
                dictionary.Entries.Add(entry);
            }
            return dictionary;
        }
    }
}
