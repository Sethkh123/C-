using System;

class Program
{
    static DictionariesManager manager = new DictionariesManager();

    static void Main(string[] args)
    {
        manager.LoadDictionaries(); // Load existing dictionaries from files

        while (true)
        {
            PrintMainMenu();

            string choice = Console.ReadLine();
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    CreateDictionary();
                    break;
                case "2":
                    AddWord();
                    break;
                case "3":
                    ReplaceWord();
                    break;
                case "4":
                    ReplaceTranslation();
                    break;
                case "5":
                    DeleteWord();
                    break;
                case "6":
                    DeleteTranslation();
                    break;
                case "7":
                    SearchTranslation();
                    break;
                case "8":
                    manager.SaveDictionaries(); // Save dictionaries to files
                    Console.WriteLine("Dictionaries saved.");
                    break;
                case "9":
                    Console.WriteLine("Exiting the program...");
                    return;
                default:
                    Console.WriteLine("Invalid option. Please choose again.");
                    break;
            }

            Console.WriteLine();
        }
    }

    static void PrintMainMenu()
    {
        Console.WriteLine("=== Dictionaries Application ===");
        Console.WriteLine("1. Create Dictionary");
        Console.WriteLine("2. Add Word");
        Console.WriteLine("3. Replace Word");
        Console.WriteLine("4. Replace Translation");
        Console.WriteLine("5. Delete Word");
        Console.WriteLine("6. Delete Translation");
        Console.WriteLine("7. Search Translation");
        Console.WriteLine("8. Save Dictionaries");
        Console.WriteLine("9. Exit");
        Console.Write("Choose an option: ");
    }

    static void CreateDictionary()
    {
        Console.Write("Enter dictionary language: ");
        string language = Console.ReadLine();
        manager.CreateDictionary(language);
    }

    static void AddWord()
    {
        Console.Write("Enter dictionary language: ");
        string language = Console.ReadLine();
        var dictToAdd = manager.GetDictionary(language);
        if (dictToAdd != null)
        {
            Console.Write("Enter word: ");
            string word = Console.ReadLine();
            Console.Write("Enter translation: ");
            string translation = Console.ReadLine();
            dictToAdd.AddWord(word, translation);
            Console.WriteLine($"Word '{word}' with translation '{translation}' added to '{language}' dictionary.");
        }
        else
        {
            Console.WriteLine($"Dictionary '{language}' does not exist. Please create the dictionary first.");
        }
    }

    static void ReplaceWord()
    {
        Console.Write("Enter dictionary language: ");
        string language = Console.ReadLine();
        var dictToReplace = manager.GetDictionary(language);
        if (dictToReplace != null)
        {
            Console.Write("Enter old word: ");
            string oldWord = Console.ReadLine();
            Console.Write("Enter new word: ");
            string newWord = Console.ReadLine();
            dictToReplace.ReplaceWord(oldWord, newWord);
            Console.WriteLine($"Word '{oldWord}' replaced with '{newWord}' in '{language}' dictionary.");
        }
        else
        {
            Console.WriteLine($"Dictionary '{language}' does not exist. Please create the dictionary first.");
        }
    }

    static void ReplaceTranslation()
    {
        Console.Write("Enter dictionary language: ");
        string language = Console.ReadLine();
        var dictToReplaceTrans = manager.GetDictionary(language);
        if (dictToReplaceTrans != null)
        {
            Console.Write("Enter word: ");
            string word = Console.ReadLine();
            Console.Write("Enter old translation: ");
            string oldTranslation = Console.ReadLine();
            Console.Write("Enter new translation: ");
            string newTranslation = Console.ReadLine();
            dictToReplaceTrans.ReplaceTranslation(word, oldTranslation, newTranslation);
            Console.WriteLine($"Translation '{oldTranslation}' of '{word}' replaced with '{newTranslation}' in '{language}' dictionary.");
        }
        else
        {
            Console.WriteLine($"Dictionary '{language}' does not exist. Please create the dictionary first.");
        }
    }

    static void DeleteWord()
    {
        Console.Write("Enter dictionary language: ");
        string language = Console.ReadLine();
        var dictToDelete = manager.GetDictionary(language);
        if (dictToDelete != null)
        {
            Console.Write("Enter word: ");
            string word = Console.ReadLine();
            dictToDelete.DeleteWord(word);
            Console.WriteLine($"Word '{word}' deleted from '{language}' dictionary.");
        }
        else
        {
            Console.WriteLine($"Dictionary '{language}' does not exist. Please create the dictionary first.");
        }
    }

    static void DeleteTranslation()
    {
        Console.Write("Enter dictionary language: ");
        string language = Console.ReadLine();
        var dictToDeleteTrans = manager.GetDictionary(language);
        if (dictToDeleteTrans != null)
        {
            Console.Write("Enter word: ");
            string word = Console.ReadLine();
            Console.Write("Enter translation: ");
            string translation = Console.ReadLine();
            dictToDeleteTrans.DeleteTranslation(word, translation);
            Console.WriteLine($"Translation '{translation}' deleted from '{word}' in '{language}' dictionary.");
        }
        else
        {
            Console.WriteLine($"Dictionary '{language}' does not exist. Please create the dictionary first.");
        }
    }

    static void SearchTranslation()
    {
        Console.Write("Enter dictionary language: ");
        string language = Console.ReadLine();
        var dictToSearch = manager.GetDictionary(language);
        if (dictToSearch != null)
        {
            Console.Write("Enter word: ");
            string word = Console.ReadLine();
            var translations = dictToSearch.SearchTranslation(word);
            if (translations != null && translations.Count > 0)
            {
                Console.WriteLine($"Translations of '{word}' in '{language}':");
                foreach (var translation in translations)
                {
                    Console.WriteLine($"- {translation}");
                }
            }
            else
            {
                Console.WriteLine($"No translations found for '{word}' in '{language}' dictionary.");
            }
        }
        else
        {
            Console.WriteLine($"Dictionary '{language}' does not exist. Please create the dictionary first.");
        }
    }
}
