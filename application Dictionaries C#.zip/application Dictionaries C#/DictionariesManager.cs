using System;
using System.Collections.Generic;
using System.IO;

public class DictionariesManager
{
    private List<Dictionary> dictionaries = new List<Dictionary>();

    public void CreateDictionary(string language)
    {
        var existingDict = dictionaries.Find(d => d.Language == language);
        if (existingDict == null)
        {
            var newDictionary = new Dictionary(language);
            dictionaries.Add(newDictionary);
            Console.WriteLine($"Dictionary for '{language}' created.");
        }
        else
        {
            Console.WriteLine($"Dictionary for '{language}' already exists.");
        }
    }

    public Dictionary GetDictionary(string language)
    {
        return dictionaries.Find(d => d.Language == language);
    }

    public void SaveDictionaries()
    {
        foreach (var dictionary in dictionaries)
        {
            string filePath = $"{dictionary.Language}.txt";
            dictionary.SaveToFile(filePath);
        }
    }

    public void LoadDictionaries()
    {
        foreach (var filePath in Directory.GetFiles(".", "*.txt"))
        {
            dictionaries.Add(Dictionary.LoadFromFile(filePath));
        }
    }
}
