using System.Collections.Generic;

public class DictionaryEntry
{
    public string Word { get; set; }
    public List<string> Translations { get; set; }

    public DictionaryEntry(string word)
    {
        Word = word;
        Translations = new List<string>();
    }
}
